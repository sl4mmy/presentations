/*
 * Copyright (c) 2009, Kent R. Spillner <kspillner@acm.org>
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
package tao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Understands how to transport passengers between floors.
 */
public class Elevator {
    private Floor currentFloor;

    public Floor callToFloor(Floor floor, Direction directionOfTravel) {
        processFloorRequests(toFloorRequest(floor), directionOfTravel);
        return currentFloor;
    }

    public Floor getCurrentFloor() {
        return currentFloor;
    }

    public List<Floor> processFloorRequests(List<Floor> floorRequests, Direction directionOfTravel) {
        List<Floor> orderedFloorRequestsInDirection = orderFloorRequestsInDirection(floorRequests, directionOfTravel);
        List<Floor> historyInCurrentDirection = processOrderedFloorRequests(orderedFloorRequestsInDirection);
        List<Floor> history = new ArrayList<Floor>(historyInCurrentDirection);

        if (history.size() != floorRequests.size()) {
            List<Floor> orderedFloorRequestsInOppositeDirection = orderFloorRequestsInDirection(floorRequests, directionOfTravel.opposite());
            List<Floor> historyInOppositeDirection = processOrderedFloorRequests(orderedFloorRequestsInOppositeDirection);
            history.addAll(historyInOppositeDirection);
        }

        return history;
    }

    public Floor pushButtonForFloor(Floor floor) {
        processFloorRequests(toFloorRequest(floor), Direction.UP);
        return currentFloor;
    }

    private List<Floor> orderFloorRequestsInDirection(List<Floor> floorRequests, Direction directionOfTravel) {
        List<Floor> orderedFloorRequests = new ArrayList<Floor>(floorRequests);

        for (Floor floor : floorRequests) {
            // If floor -> currentFloor == directionOfTravel, then floor is actually in the opposite direction
            Direction directionToCurrentFloor = floor.directionTo(currentFloor);
            if (directionToCurrentFloor == directionOfTravel) {
                orderedFloorRequests.remove(floor);
            }
        }

        Collections.sort(orderedFloorRequests, directionOfTravel.getComparator());

        return orderedFloorRequests;
    }

    private List<Floor> processOrderedFloorRequests(List<Floor> orderedFloorRequests) {
        List<Floor> history = new ArrayList<Floor>();

        for (Floor floor : orderedFloorRequests) {
            if (currentFloor == null || !currentFloor.equals(floor)) {
                currentFloor = floor;
                history.add(floor);
            }
        }

        return history;
    }

    private List<Floor> toFloorRequest(final Floor floor) {
        return new ArrayList<Floor>() {
            {
                add(floor);
            }
        };
    }
}
