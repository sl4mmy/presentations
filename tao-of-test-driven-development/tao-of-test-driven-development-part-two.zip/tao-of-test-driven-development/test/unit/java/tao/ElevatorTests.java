/*
 * Copyright (c) 2009, Kent R. Spillner <kspillner@acm.org>
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
package tao;

import junit.framework.JUnit4TestAdapter;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class ElevatorTests {
    @Test
    public void shouldTravelToFloorWhenCalled() throws Exception {
        Floor tenthFloor = new Floor(10);

        Elevator elevator = new Elevator();

        Floor currentFloor = elevator.callToFloor(tenthFloor, Direction.UP);

        assertEquals(tenthFloor, currentFloor);
    }

    @Test
    public void shouldStayOnCurrentFloorWhenCalledToSameFloor() throws Exception {
        Floor tenthFloor = new Floor(10);

        Elevator elevator = new Elevator();

        Floor currentFloor = elevator.callToFloor(tenthFloor, Direction.UP);

        assertSame(currentFloor, elevator.callToFloor(new Floor(10), Direction.UP));
    }

    @Test
    public void shouldTravelToFloorWhenCorrespondingButtonInElevatorIsPushed() throws Exception {
        Floor tenthFloor = new Floor(10);

        Elevator elevator = new Elevator();

        Floor currentFloor = elevator.pushButtonForFloor(tenthFloor);

        assertEquals(tenthFloor, currentFloor);
    }

    @Test
    public void shouldStayOnLastFloor() throws Exception {
        Floor firstFloor = new Floor(1);
        Floor secondFloor = new Floor(2);
        Floor thirdFloor = new Floor(3);

        List<Floor> floorRequests = new ArrayList<Floor>();
        floorRequests.add(thirdFloor);
        floorRequests.add(secondFloor);
        floorRequests.add(firstFloor);

        Elevator elevator = new Elevator();

        elevator.processFloorRequests(floorRequests, Direction.DOWN);
        Floor currentFloor = elevator.getCurrentFloor();

        assertEquals(firstFloor, currentFloor);
    }

    @Test
    public void shouldStopAtFirstRequestedFloorBeforeStoppingAtSecondRequestedFloor() throws Exception {
        Floor firstFloor = new Floor(1);
        Floor secondFloor = new Floor(2);

        List<Floor> floorRequests = new ArrayList<Floor>();
        floorRequests.add(firstFloor);
        floorRequests.add(secondFloor);

        Elevator elevator = new Elevator();

        List<Floor> history = elevator.processFloorRequests(floorRequests, Direction.UP);

        assertEquals(firstFloor, history.get(0));
        assertEquals(secondFloor, history.get(1));
    }

    @Test
    public void shouldStopAtSecondRequestedFloorFirstWhenItIsOnTheWayToTheFirstRequestedFloor() throws Exception {
        Floor firstFloor = new Floor(1);
        Floor secondFloor = new Floor(2);

        List<Floor> floorRequests = new ArrayList<Floor>();
        floorRequests.add(secondFloor);
        floorRequests.add(firstFloor);

        Elevator elevator = new Elevator();

        List<Floor> history = elevator.processFloorRequests(floorRequests, Direction.UP);

        assertEquals(firstFloor, history.get(0));
        assertEquals(secondFloor, history.get(1));
    }

    @Test
    public void shouldStopAtEveryRequestedFloor() throws Exception {
        Floor firstFloor = new Floor(1);
        Floor secondFloor = new Floor(2);
        Floor thirdFloor = new Floor(3);

        List<Floor> floorRequests = new ArrayList<Floor>();
        floorRequests.add(thirdFloor);
        floorRequests.add(firstFloor);
        floorRequests.add(secondFloor);

        Elevator elevator = new Elevator();

        List<Floor> history = elevator.processFloorRequests(floorRequests, Direction.DOWN);

        assertEquals(true, history.contains(firstFloor));
        assertEquals(true, history.contains(secondFloor));
        assertEquals(true, history.contains(thirdFloor));
    }

    @Test
    public void shouldStopAtEachRequestedFloorInTheOrderInWhichTheyArePassed() throws Exception {
        Floor firstFloor = new Floor(1);
        Floor secondFloor = new Floor(2);
        Floor thirdFloor = new Floor(3);

        List<Floor> floorRequests = new ArrayList<Floor>();
        floorRequests.add(thirdFloor);
        floorRequests.add(firstFloor);
        floorRequests.add(secondFloor);

        Elevator elevator = new Elevator();

        List<Floor> history = elevator.processFloorRequests(floorRequests, Direction.DOWN);

        assertEquals(thirdFloor, history.get(0));
        assertEquals(secondFloor, history.get(1));
        assertEquals(firstFloor, history.get(2));
    }

    @Test
    public void shouldStopAtAllFloorsInCurrentDirectionBeforeReturningToFloorsInOppositeDirection() throws Exception {
        Floor firstFloor = new Floor(1);
        Floor secondFloor = new Floor(2);
        Floor thirdFloor = new Floor(3);

        List<Floor> floorRequests = new ArrayList<Floor>();
        floorRequests.add(firstFloor);
        floorRequests.add(thirdFloor);

        Elevator elevator = new Elevator();

        elevator.callToFloor(secondFloor, Direction.UP); // Starting on the 2nd floor...
        List<Floor> history = elevator.processFloorRequests(floorRequests, Direction.UP);

        assertEquals(thirdFloor, history.get(0));
        assertEquals(firstFloor, history.get(1));
    }

    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(ElevatorTests.class);
    }
}
