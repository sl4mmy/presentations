/*
 * Copyright (c) 2009, Kent R. Spillner <kspillner@acm.org>
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
package tao;

import junit.framework.JUnit4TestAdapter;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class FloorTests {
    @Test
    public void shouldBeEqualToSelf() throws Exception {
        final Floor floor = new Floor(1);

        assertEquals(true, floor.equals(floor));
    }

    @Test
    public void shouldNotBeEqualToNull() throws Exception {
        final Floor floor = new Floor(1);

        assertEquals(false, floor.equals(null));
    }

    @Test
    public void shouldNotBeEqualToInstancesOfOtherTypes() throws Exception {
        final Floor floor = new Floor(1);

        assertEquals(false, floor.equals(new Object()));
    }

    @Test
    public void shouldBeEqualToDifferentInstancesWithSameValue() throws Exception {
        final Floor left = new Floor(1);
        final Floor right = new Floor(1);

        assertEquals(true, left.equals(right));
    }

    @Test
    public void shouldNotBeEqualToDifferentInstancesWithDifferentValue() throws Exception {
        final Floor firstFloor = new Floor(1);
        final Floor secondFloor = new Floor(2);

        assertEquals(false, firstFloor.equals(secondFloor));
    }

    @Test
    public void hashCodeShouldBeValue() throws Exception {
        final Floor floor = new Floor(1);

        assertEquals(1, floor.hashCode());
    }

    @Test
    public void shouldBeComparable() throws Exception {
        assertEquals(true, new Floor(1) instanceof Comparable);
    }

    @Test
    public void compareToShouldReturnThisValueMinusOtherValue() throws Exception {
        final Comparable firstFloor = new Floor(1);
        final Comparable fifthFloor = new Floor(5);

        assertEquals(0, firstFloor.compareTo(firstFloor));
        assertEquals(-4, firstFloor.compareTo(fifthFloor));
        assertEquals(4, fifthFloor.compareTo(firstFloor));
    }

    @Test
    public void directionToOtherFloorShouldDefaultToNoneWhenValuesAreEqual() throws Exception {
        assertEquals(Direction.NONE, new Floor(1).directionTo(new Floor(1)));
    }

    @Test
    public void directionToOtherFloorShouldDefaultToNoneWhenOtherIsNull() throws Exception {
        assertEquals(Direction.NONE, new Floor(1).directionTo(null));
    }

    @Test
    public void directionToOtherFloorShouldBeUpWhenValueIsLessThanOtherValue() throws Exception {
        final Floor firstFloor = new Floor(1);
        final Floor fifthFloor = new Floor(5);

        assertEquals(Direction.UP, firstFloor.directionTo(fifthFloor));
    }

    @Test
    public void directionToOtherFloorShouldBeDownWhenValueIsGreaterThanOtherValue() throws Exception {
        final Floor firstFloor = new Floor(1);
        final Floor fifthFloor = new Floor(5);

        assertEquals(Direction.DOWN, fifthFloor.directionTo(firstFloor));
    }

    @Test
    public void shouldBeEvenWhenValueIsEven() throws Exception {
        final Floor secondFloor = new Floor(2);

        assertEquals(true, secondFloor.isEven());
    }

    @Test
    public void shouldNotBeEvenWhenValueIsNotEven() throws Exception {
        final Floor firstFloor = new Floor(1);

        assertEquals(false, firstFloor.isEven());
    }

    @Test
    public void shouldBeOddWhenValueIsOdd() throws Exception {
        final Floor firstFloor = new Floor(1);

        assertEquals(true, firstFloor.isOdd());
    }

    @Test
    public void shouldNotBeOddWhenValueIsNotOdd() throws Exception {
        final Floor secondFloor = new Floor(2);

        assertEquals(false, secondFloor.isOdd());
    }

    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(FloorTests.class);
    }
}
